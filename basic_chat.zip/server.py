import socket
import time
host_name ="localhost"
port= 5555
internet_soket= socket.socket()
internet_soket.bind((host_name ,port))
internet_soket.listen(1)

bağlantı, adres =internet_soket.accept()
print(str(adres)+"bağlantı sağlandı")


while True:
    while True:
        try:
            gelen_veri = str(bağlantı.recv(1824).decode())
            print("gelen mesaj "+ gelen_veri)
            break
        except:
            time.sleep(2)
            bağlantı ,adres= internet_soket.accept
            print(src(adres)+ "bağlantı sağlandı")
    
    if gelen_veri == "çıkış":
        break
    else:
        mesaj = input("-----")
        print("bağlantı sağlanıyor")
        bağlantı.send(mesaj.encode())


bağlantı.close()
