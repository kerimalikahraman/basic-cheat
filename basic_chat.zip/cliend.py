import socket
import time

isim = input( "isminizi giriniz")

host_name ="localhost"
port= 5555
internet_soket= socket.socket()
internet_soket.connect((host_name ,port))


print("bağlantı sağlandı".format(host_name,port))
mesaj = input("-------")
print("server bekleniyor")

while mesaj != "çıkış":
    internet_soket.send(mesaj.encode())
    gelen_veri = internet_soket.recv(1024).decode()

    print ("server "+gelen_veri)
    
    mesaj = input("-------")
    print("server bekleniyor...")

internet_soket.close()
